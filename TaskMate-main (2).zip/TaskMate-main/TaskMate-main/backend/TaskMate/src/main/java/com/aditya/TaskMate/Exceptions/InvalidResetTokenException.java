package com.aditya.TaskMate.Exceptions;

public class InvalidResetTokenException extends RuntimeException {
	public InvalidResetTokenException(String message) {
		super(message);
	}
}
