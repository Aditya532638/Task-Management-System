package com.aditya.TaskMate;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskMateApplicationTests {

	@Test
	void contextLoads() {
	}

}
