export const priorityMapping = {
  1: "High",
  2: "Medium",
  3: "Low",
};
